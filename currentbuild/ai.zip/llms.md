# thoroak.fhir.no.ig#0.1.0: Min Implementasjonsguide

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [Krav](krav.md)
* [Prosess](prosess.md)
* [Aktorer](aktorer.md)
* [Informasjonsbehov](informasjonsbehov.md)

## Resources

### Resource Profiles

* [Home blood pressure monitor](StructureDefinition-minig-device-blodtrykksapparat.md)
* [Blood pressure observation](StructureDefinition-minig-observation-blodtrykk.md)
* [Pasient](StructureDefinition-minig-patient.md)

### CapabilityStatements

* [MinIG Home Blood Pressure Capability Statement](CapabilityStatement-MinIGCapabilityStatement.md)

### ImplementationGuides

* [Min Implementasjonsguide](index.md)

### Examples

* [karin-blodtrykksapparat (Device)](Device-karin-blodtrykksapparat.md)
* [blodtrykk-innsendt (Observation)](Observation-blodtrykk-innsendt.md)
* [blodtrykk-vurdert (Observation)](Observation-blodtrykk-vurdert.md)
* [karin-testdal (Patient)](Patient-karin-testdal.md)
* [sara-testesen (Practitioner)](Practitioner-sara-testesen.md)
* [blodtrykk-vurdering (Provenance)](Provenance-blodtrykk-vurdering.md)
