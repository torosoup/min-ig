# thoroak.fhir.no.ig#0.1.0: Min Implementasjonsguide

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [Blodprøve](StructureDefinition-minig-observation-blodprove.md)
* [Pasient](StructureDefinition-minig-patient.md)

### ImplementationGuides

* [Min Implementasjonsguide](index.md)

### Examples

* [Pasient-1 (Patient)](Patient-Pasient-1.md)
